"""
NEUROTRADER PRO - Motor de Analisis v7
3 Estrategias | Vencimiento 5 min | EMA9/EMA21 | Stochastic(14,3,3) | CMF(10)
"""
import time
import logging
import threading
import json as _json
import os as _os
from datetime import datetime, timedelta
import pandas as pd
import numpy as np
import pytz
from collections import defaultdict, deque
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading as _threading

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

ecuador = pytz.timezone("America/Guayaquil")

# ─────────────────────────────────────────────
# CONFIGURACION GLOBAL
# ─────────────────────────────────────────────
DURACION_OPERACION      = 5     # Todas las operaciones a 5 minutos
MAX_OPS_POR_HORA_POR_ACTIVO = 3
MAX_CONCURRENT_TRADES   = 1
PAUSA_ENTRE_LOTES       = 30
PAUSA_CALIENTES         = 5
PAUSA_TRAS_PERDIDAS     = 2     # minutos
MAX_PERDIDAS_CONSECUTIVAS = 2
MAX_SCAN_WORKERS        = 6
MARTINGALA_MAX_NIVEL    = 1

# Umbrales de score minimo para operar
MIN_SCORE_PARA_OPERAR   = 55
UMBRAL_PRESENAL         = 35

# Filtros globales - Mercado Normal
MFM_MINIMO_NORMAL       = 0.20
# Filtros globales - Mercado OTC
MFM_MINIMO_OTC          = 0.28

# Stochastic: < 83 para CALL, > 17 para PUT (ambos mercados)
STOCH_MAX_CALL          = 83
STOCH_MIN_PUT           = 17

# EMA para tendencia
EMA_RAPIDA              = 9
EMA_LENTA               = 21
EMA_MARGEN_LATERAL      = 0.0002   # si |EMA9-EMA21|/EMA21 < margen -> lateral

# ─────────────────────────────────────────────
# ACTIVOS A VIGILAR
# ─────────────────────────────────────────────
ACTIVOS_NORMALES = [
    'EURUSD', 'GBPUSD', 'USDJPY', 'AUDUSD', 'XAUUSD',
    'GBPJPY', 'EURJPY', 'USDCAD', 'NZDUSD', 'USDCHF',
]
ACTIVOS_OTC = [
    'EURUSD-OTC', 'GBPUSD-OTC', 'USDJPY-OTC', 'EURGBP-OTC', 'EURJPY-OTC',
    'GBPJPY-OTC', 'NZDUSD-OTC', 'USDCHF-OTC', 'AUDCAD-OTC', 'USDSGD-OTC',
]
ACTIVOS_OBJETIVO = ACTIVOS_NORMALES + ACTIVOS_OTC

def es_otc(asset: str) -> bool:
    return asset.upper().endswith('-OTC')


# ─────────────────────────────────────────────
# SISTEMA DE LICENCIAS
# ─────────────────────────────────────────────
LICENCIAS_FILE = "licencias.json"


def _cargar_licencias() -> dict:
    if _os.path.exists(LICENCIAS_FILE):
        try:
            with open(LICENCIAS_FILE, 'r', encoding='utf-8') as f:
                return _json.load(f)
        except Exception:
            pass
    return {}


def validar_licencia(codigo: str, email: str = None) -> tuple:
    codigo = codigo.strip().upper() if codigo else ""
    if not codigo:
        return False, "Codigo de licencia requerido"
    licencias = _cargar_licencias()
    if not licencias:
        return False, "No hay licencias registradas. Contacte al administrador."
    if codigo not in licencias:
        return False, f"Codigo '{codigo}' no valido"
    lic = licencias[codigo]
    if not lic.get('active', True):
        return False, "Licencia desactivada. Contacte al administrador."
    expires = lic.get('expires')
    if expires:
        try:
            exp_date = datetime.fromisoformat(expires)
            if 'T' not in expires and ':' not in expires:
                exp_date = exp_date.replace(hour=23, minute=59, second=59)
            if datetime.now() > exp_date:
                return False, f"Licencia expirada el {expires[:10]}"
        except Exception:
            pass
    lic_email = lic.get('email', '').strip().lower()
    if lic_email and email:
        if email.strip().lower() != lic_email:
            return False, "Este codigo no corresponde al correo ingresado"
    plan = lic.get('plan', '')
    plan_txt = {
        'semanal': 'Plan Semanal',
        'mensual': 'Plan Mensual',
        'vitalicio': 'Plan Vitalicio'
    }.get(plan, 'acceso completo')
    return True, f"Licencia valida — {plan_txt}"


def crear_licencia(codigo: str, descripcion: str = '', expires: str = None) -> bool:
    licencias = _cargar_licencias()
    licencias[codigo.strip().upper()] = {
        'active':      True,
        'descripcion': descripcion,
        'expires':     expires,
        'creado':      datetime.now().isoformat()[:19],
    }
    try:
        with open(LICENCIAS_FILE, 'w', encoding='utf-8') as f:
            _json.dump(licencias, f, indent=2, ensure_ascii=False)
        return True
    except Exception:
        return False


# ─────────────────────────────────────────────
# MEMORIA ADAPTATIVA
# ─────────────────────────────────────────────
UMBRAL_CONFIANZA_ACTIVO = 0.40

class AdaptiveMemory:
    def __init__(self, ventana=25):
        self.ventana = ventana
        self.historial_asset      = defaultdict(lambda: deque(maxlen=ventana))
        self.historial_estrategia = defaultdict(lambda: deque(maxlen=ventana))
        self.historial_combo      = defaultdict(lambda: deque(maxlen=ventana))
        self.racha_asset          = defaultdict(int)

    def registrar(self, asset, estrategia, gano, regimen='BULL', direccion='CALL'):
        val = 1 if gano else 0
        self.historial_asset[asset].append(val)
        self.historial_estrategia[estrategia].append(val)
        self.historial_combo[f"{asset}::{estrategia}"].append(val)
        if gano:
            self.racha_asset[asset] = max(0, self.racha_asset[asset]) + 1
        else:
            self.racha_asset[asset] = min(0, self.racha_asset[asset]) - 1

    def win_rate_asset(self, asset):
        h = self.historial_asset[asset]
        if len(h) < 3:
            return 0.65
        return sum(h) / len(h)

    def factor_confianza(self, asset, estrategia):
        wr_a = self.win_rate_asset(asset)
        h_e  = self.historial_estrategia[estrategia]
        wr_e = sum(h_e) / len(h_e) if len(h_e) >= 3 else 0.65
        h_c  = self.historial_combo[f"{asset}::{estrategia}"]
        wr_c = sum(h_c) / len(h_c) if len(h_c) >= 2 else 0.65
        factor = wr_a * 0.35 + wr_e * 0.30 + wr_c * 0.35
        if wr_a < UMBRAL_CONFIANZA_ACTIVO:
            factor *= 0.6
        racha = self.racha_asset.get(asset, 0)
        if racha >= 3:
            factor = min(1.5, factor * 1.15)
        elif racha <= -3:
            factor = max(0.1, factor * 0.70)
        return factor

    def resumen_aprendizaje(self):
        resumen = {}
        for asset, h in self.historial_asset.items():
            if len(h) >= 3:
                wr = sum(h) / len(h)
                resumen[asset] = {'win_rate': round(wr, 3), 'ops': len(h), 'racha': self.racha_asset.get(asset, 0)}
        return dict(sorted(resumen.items(), key=lambda x: -x[1]['win_rate']))


# ─────────────────────────────────────────────
# ESTADO DEL BOT
# ─────────────────────────────────────────────
class BotState:
    def __init__(self):
        self.running         = False
        self.logs            = []
        self.trades          = []
        self.active_trades   = []
        self.saldo           = 0.0
        self.saldo_inicial   = 0.0
        self.api             = None
        self.tipo_cuenta     = "PRACTICE"
        self.monto           = 1.0
        self.asset_ops_hist  = defaultdict(list)
        self.stats = {
            'total': 0, 'ganadas': 0, 'perdidas': 0, 'devueltas': 0,
            'profit': 0.0,
            'por_estrategia': {
                'sop_res':  {'total': 0, 'ganadas': 0},
                'pin_bar':  {'total': 0, 'ganadas': 0},
                'rechazo':  {'total': 0, 'ganadas': 0},
            }
        }
        self.estrategias_activas = {
            'sop_res': True,
            'pin_bar': True,
            'rechazo': True,
        }
        self.ops_dia          = 0
        self.max_ops_dia      = None
        self.ops_dia_fecha    = None
        self.bloqueo_asset_est = {}
        self.martingala_activa      = False
        self.martingala_nivel       = 0
        self.martingala_monto_base  = 0.0
        self.martingala_pendiente   = None
        self.activos_disponibles    = []
        self.señal_actual           = None
        self.scan_progreso          = 0
        self.scan_total             = 0
        self.ia                     = AdaptiveMemory(ventana=25)
        self.regimenes              = {}
        self._email                 = ""
        self._password              = ""
        self.perdidas_consecutivas  = 0
        self.pausa_hasta            = None
        self._ultimo_refresh_activos= 0
        self._candidatos_cache      = []
        self._cursor_activos        = 0
        self._ultimo_ciclo_min      = -1
        self._lista_caliente        = {}
        self.tipo_operacion         = 'binaria'

    @property
    def current_trade(self):
        return self.active_trades[0] if self.active_trades else None

    def add_log(self, msg, nivel="INFO"):
        ts = datetime.now(ecuador).strftime('%H:%M:%S')
        self.logs.append({"time": ts, "msg": msg, "nivel": nivel})
        if len(self.logs) > 400:
            self.logs = self.logs[-400:]

    def add_trade(self, trade):
        self.trades.append(trade)
        self.stats['total'] += 1
        est  = trade.get('estrategia', 'sop_res')
        gano = trade['estado'] == 'GANADA'
        self.ia.registrar(trade['asset'], est, gano,
                          regimen=trade.get('regimen', 'BULL'),
                          direccion=trade.get('direccion', 'CALL'))
        if est in self.stats['por_estrategia']:
            self.stats['por_estrategia'][est]['total'] += 1
            if gano:
                self.stats['por_estrategia'][est]['ganadas'] += 1
        if gano:
            self.stats['ganadas'] += 1
            self.stats['profit'] += trade.get('ganancia', 0)
            self.perdidas_consecutivas = 0
        elif trade['estado'] == 'PERDIDA':
            self.stats['perdidas'] += 1
            self.stats['profit'] -= trade['monto']
            self.perdidas_consecutivas += 1
            if self.perdidas_consecutivas >= MAX_PERDIDAS_CONSECUTIVAS:
                self.pausa_hasta = datetime.now(ecuador) + timedelta(minutes=PAUSA_TRAS_PERDIDAS)
                self.add_log(
                    f"Pausa activada: {self.perdidas_consecutivas} perdidas consecutivas. "
                    f"Reanudando a las {self.pausa_hasta.strftime('%H:%M')}",
                    "WARN"
                )
        else:
            self.stats['devueltas'] += 1
        if len(self.trades) > 300:
            self.trades = self.trades[-300:]

    def puede_operar_asset(self, asset):
        ahora = datetime.now(ecuador)
        hace_una_hora = ahora - timedelta(hours=1)
        ops = [t for t in self.asset_ops_hist[asset] if t > hace_una_hora]
        self.asset_ops_hist[asset] = ops
        return len(ops) < MAX_OPS_POR_HORA_POR_ACTIVO

    def registrar_op(self, asset):
        self.asset_ops_hist[asset].append(datetime.now(ecuador))

    @property
    def win_rate(self):
        cerradas = self.stats['ganadas'] + self.stats['perdidas']
        return (self.stats['ganadas'] / cerradas * 100) if cerradas > 0 else 0.0


# ─────────────────────────────────────────────
# OBTENCIÓN DE DATOS
# ─────────────────────────────────────────────
def obtener_activos_disponibles(api):
    """Retorna solo los activos del listado objetivo que esten abiertos."""
    try:
        open_time = api.get_all_open_time()
        disponibles = []
        tipos = ['binary', 'digital', 'turbo']
        for asset in ACTIVOS_OBJETIVO:
            abierto = False
            for tipo in tipos:
                if tipo in open_time:
                    if open_time[tipo].get(asset, {}).get('open', False):
                        abierto = True
                        break
            if abierto:
                disponibles.append(asset)
        if not disponibles:
            # fallback: devolver todos los objetivo aunque no estén verificados
            return ACTIVOS_OBJETIVO[:]
        return disponibles
    except Exception as e:
        logger.error(f"Error activos: {e}")
        return ACTIVOS_OBJETIVO[:]


def is_asset_open(api, asset):
    try:
        open_time = api.get_all_open_time()
        for tipo in ['binary', 'digital', 'turbo']:
            if tipo in open_time:
                if open_time[tipo].get(asset, {}).get('open', False):
                    return True
        return False
    except:
        return False


_velas_cache     = {}
_VELAS_CACHE_TTL = 25

def obtener_velas(api, asset, n=100, forzar_fresco=False):
    ahora_ts = time.time()
    if not forzar_fresco:
        cached = _velas_cache.get(asset)
        if cached and (ahora_ts - cached[0]) < _VELAS_CACHE_TTL:
            return cached[1]
    try:
        candles = api.get_candles(asset, 60, n, ahora_ts)
        if not candles or len(candles) < 30:
            return None
        df = pd.DataFrame(candles)
        for col in ['open', 'max', 'min', 'close', 'volume']:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce')
        df.dropna(subset=['open', 'close', 'max', 'min'], inplace=True)
        if len(df) < 30:
            return None
        df.rename(columns={'max': 'high', 'min': 'low'}, inplace=True)
        df = df.reset_index(drop=True)
        _velas_cache[asset] = (ahora_ts, df)
        return df
    except Exception:
        return None


# ─────────────────────────────────────────────
# INDICADORES TÉCNICOS
# ─────────────────────────────────────────────
def calcular_indicadores(df):
    df = df.copy()
    c = df['close']
    h = df['high']
    l = df['low']
    o = df['open']
    v = df['volume'] if 'volume' in df.columns else pd.Series(0.0, index=df.index)

    # EMAs
    for span in [3, 5, 9, 13, 21, 34, 50]:
        df[f'ema{span}'] = c.ewm(span=span, adjust=False).mean()

    # SMAs
    df['sma20'] = c.rolling(20).mean()

    # Bollinger Bands
    df['bb_std']   = c.rolling(20).std()
    df['bb_upper'] = df['sma20'] + 2.0 * df['bb_std']
    df['bb_lower'] = df['sma20'] - 2.0 * df['bb_std']
    df['bb_width'] = (df['bb_upper'] - df['bb_lower']) / (df['sma20'] + 1e-10)

    # ATR 14
    tr = pd.concat([
        h - l,
        (h - c.shift(1)).abs(),
        (l - c.shift(1)).abs()
    ], axis=1).max(axis=1)
    df['atr'] = tr.ewm(com=13, adjust=False).mean()
    df['atr_pct'] = df['atr'] / (c + 1e-10)

    # MFM / MFV / ADL
    df['mfm'] = (((c - l) - (h - c)) / (h - l + 1e-10)).clip(-1, 1)
    df['mfv'] = df['mfm'] * v
    df['adl'] = df['mfv'].cumsum()

    # CMF(10) — Chaikin Money Flow 10 periodos
    df['cmf10'] = df['mfv'].rolling(10).sum() / (v.rolling(10).sum() + 1e-10)

    # Stochastic (14, 3, 3)
    lo14       = l.rolling(14).min()
    hi14       = h.rolling(14).max()
    stoch_k_raw= 100 * (c - lo14) / (hi14 - lo14 + 1e-10)
    df['stoch_k'] = stoch_k_raw.rolling(3).mean()   # %K suavizado 3
    df['stoch_d'] = df['stoch_k'].rolling(3).mean() # %D suavizado 3

    # Candle properties
    df['body']        = (c - o).abs()
    df['rango']       = h - l
    df['body_ratio']  = df['body'] / (df['rango'] + 1e-10)
    df['is_bull']     = c > o
    df['upper_wick']  = h - c.clip(lower=o)
    df['lower_wick']  = o.clip(upper=c) - l

    # Pin Bar: mecha > 2× cuerpo
    df['pat_pin_bull'] = ((df['lower_wick'] > df['body'] * 2.0) & (c >= o)).astype(int)
    df['pat_pin_bear'] = ((df['upper_wick'] > df['body'] * 2.0) & (c <= o)).astype(int)

    # Vela de Rechazo: mecha > 2× cuerpo (en zona S/R)
    df['pat_rechazo_bull'] = ((df['lower_wick'] > df['body'] * 2.0) & (df['body_ratio'] > 0.08)).astype(int)
    df['pat_rechazo_bear'] = ((df['upper_wick'] > df['body'] * 2.0) & (df['body_ratio'] > 0.08)).astype(int)

    # Volumen
    vol_mean = float(v.mean()) if v.mean() > 0 else 0.0
    df['vol_tiene_datos'] = vol_mean > 0
    if vol_mean > 0:
        vol_ma = v.rolling(14, min_periods=3).mean().fillna(vol_mean)
        df['vol_ratio'] = (v / vol_ma.replace(0, 1)).round(3)
    else:
        df['vol_ratio'] = 1.0

    # Soporte y Resistencia (pivotes simples)
    ventana_sr = 10
    df['pivot_high'] = h.rolling(ventana_sr * 2 + 1, center=True).max()
    df['pivot_low']  = l.rolling(ventana_sr * 2 + 1, center=True).min()

    return df


# ─────────────────────────────────────────────
# DETECCIÓN DE RÉGIMEN (EMA9 vs EMA21)
# ─────────────────────────────────────────────
def detectar_regimen(df):
    """
    BULL  : EMA9 > EMA21 con separacion significativa
    BEAR  : EMA9 < EMA21 con separacion significativa
    SIDEWAYS: EMA9 ≈ EMA21 (mercado lateral — no operar)
    """
    if len(df) < 22:
        return 'SIDEWAYS'
    u     = df.iloc[-1]
    e9    = float(u['ema9'])
    e21   = float(u['ema21'])
    if e21 == 0:
        return 'SIDEWAYS'
    diff_pct = (e9 - e21) / e21
    if diff_pct > EMA_MARGEN_LATERAL:
        return 'BULL'
    elif diff_pct < -EMA_MARGEN_LATERAL:
        return 'BEAR'
    return 'SIDEWAYS'


# ─────────────────────────────────────────────
# FILTRO GLOBAL
# ─────────────────────────────────────────────
def filtro_global(df, asset, direccion):
    """
    Valida los filtros globales segun tipo de mercado (Normal vs OTC).
    Retorna (ok: bool, razon: str)
    """
    u   = df.iloc[-1]
    otc = es_otc(asset)

    mfm_actual = float(u.get('mfm', 0))
    cmf_actual = float(u.get('cmf10', 0))
    sk         = float(u.get('stoch_k', 50))

    # ── MFM minimo segun mercado ───────────────────────────────────────────
    mfm_min = MFM_MINIMO_OTC if otc else MFM_MINIMO_NORMAL
    if direccion == 'CALL' and mfm_actual < mfm_min:
        return False, f"MFM={mfm_actual:.3f} < {mfm_min} (CALL bloqueado)"
    if direccion == 'PUT' and mfm_actual > -mfm_min:
        return False, f"MFM={mfm_actual:.3f} > -{mfm_min} (PUT bloqueado)"

    # ── CMF(10) direccional ────────────────────────────────────────────────
    if direccion == 'CALL' and cmf_actual <= 0:
        return False, f"CMF10={cmf_actual:.3f} <= 0 (CALL requiere flujo positivo)"
    if direccion == 'PUT' and cmf_actual >= 0:
        return False, f"CMF10={cmf_actual:.3f} >= 0 (PUT requiere flujo negativo)"

    # ── Stochastic (no sobrecomprado/sobrevendido extremo) ─────────────────
    if direccion == 'CALL' and sk >= STOCH_MAX_CALL:
        return False, f"Stoch%K={sk:.1f} >= {STOCH_MAX_CALL} (sobrecomprado, no CALL)"
    if direccion == 'PUT' and sk <= STOCH_MIN_PUT:
        return False, f"Stoch%K={sk:.1f} <= {STOCH_MIN_PUT} (sobrevendido, no PUT)"

    return True, f"OK (MFM={mfm_actual:.3f}, CMF10={cmf_actual:.3f}, Stoch={sk:.1f})"


# ─────────────────────────────────────────────
# ESTRATEGIAS
# ─────────────────────────────────────────────

def estrategia_soporte_resistencia(df, regimen):
    """
    Soporte y Resistencia:
    CALL: precio toca zona de soporte (minimo de las ultimas 20 velas) y rebota (vela alcista)
    PUT : precio toca zona de resistencia (maximo de las ultimas 20 velas) y rechaza (vela bajista)
    """
    if len(df) < 25:
        return None, 0
    u    = df.iloc[-1]
    p    = df.iloc[-2]
    c    = float(u['close'])
    h_c  = float(u['high'])
    l_c  = float(u['low'])
    atr  = float(u.get('atr', 0)) or 1e-10

    # Zona de soporte: minimo de las ultimas 20 velas (excluye la actual)
    ventana = df.iloc[-21:-1]
    soporte     = float(ventana['low'].min())
    resistencia = float(ventana['high'].max())

    margen = atr * 1.5

    score = 0
    dir_  = None

    # CALL: toco soporte y cerro por encima (rebote)
    if l_c <= soporte + margen and c > float(p['close']) and float(u['is_bull']):
        dir_ = 'CALL'
        score = 58
        # Bonus por pin bar o mecha de rechazo
        if int(u.get('pat_pin_bull', 0)) or int(u.get('pat_rechazo_bull', 0)):
            score += 12
        # Bonus por regimen
        if regimen == 'BULL':
            score += 10
        elif regimen == 'SIDEWAYS':
            score = 0
            dir_  = None

    # PUT: toco resistencia y cerro por debajo (rechazo)
    elif h_c >= resistencia - margen and c < float(p['close']) and not float(u['is_bull']):
        dir_ = 'PUT'
        score = 58
        if int(u.get('pat_pin_bear', 0)) or int(u.get('pat_rechazo_bear', 0)):
            score += 12
        if regimen == 'BEAR':
            score += 10
        elif regimen == 'SIDEWAYS':
            score = 0
            dir_  = None

    if not dir_ or score < 50:
        return None, 0
    return dir_, min(score, 100)


def estrategia_pin_bar(df, regimen):
    """
    Pin Bar:
    CALL: pin bar alcista (mecha inferior larga >= 3× cuerpo) en zona de soporte o tendencia BULL
    PUT : pin bar bajista (mecha superior larga >= 3× cuerpo) en zona de resistencia o tendencia BEAR
    """
    if len(df) < 20:
        return None, 0
    u   = df.iloc[-1]
    p   = df.iloc[-2]

    pin_bull = int(u.get('pat_pin_bull', 0))
    pin_bear = int(u.get('pat_pin_bear', 0))

    score = 0
    dir_  = None

    if pin_bull and regimen in ('BULL',):
        dir_  = 'CALL'
        score = 62
        # cuerpo fuerte = mas confianza
        if float(u.get('body_ratio', 0)) > 0.15:
            score += 8
        # EMA9 sobre EMA21 confirma tendencia
        if float(u['ema9']) > float(u['ema21']):
            score += 10

    elif pin_bear and regimen in ('BEAR',):
        dir_  = 'PUT'
        score = 62
        if float(u.get('body_ratio', 0)) > 0.15:
            score += 8
        if float(u['ema9']) < float(u['ema21']):
            score += 10

    if not dir_ or score < 55:
        return None, 0
    return dir_, min(score, 100)


def estrategia_vela_rechazo(df, regimen):
    """
    Vela de Rechazo:
    CALL: vela con mecha inferior > 2× cuerpo (rechazo desde abajo) en tendencia BULL
    PUT : vela con mecha superior > 2× cuerpo (rechazo desde arriba) en tendencia BEAR
    Entrada en zona s59-s01 (ventana del motor principal).
    """
    if len(df) < 20:
        return None, 0
    u = df.iloc[-1]
    p = df.iloc[-2]

    rec_bull = int(u.get('pat_rechazo_bull', 0))
    rec_bear = int(u.get('pat_rechazo_bear', 0))

    score = 0
    dir_  = None

    if rec_bull and regimen == 'BULL':
        dir_  = 'CALL'
        score = 60
        # Precio por encima de EMA9 = confirmacion
        if float(u['close']) > float(u['ema9']):
            score += 8
        # Pin bar = señal mas fuerte
        if int(u.get('pat_pin_bull', 0)):
            score += 10
        # Vela anterior bajista (rechazo autentico)
        if not bool(p.get('is_bull', True)):
            score += 8

    elif rec_bear and regimen == 'BEAR':
        dir_  = 'PUT'
        score = 60
        if float(u['close']) < float(u['ema9']):
            score += 8
        if int(u.get('pat_pin_bear', 0)):
            score += 10
        if bool(p.get('is_bull', False)):
            score += 8

    if not dir_ or score < 55:
        return None, 0
    return dir_, min(score, 100)


# ─────────────────────────────────────────────
# REGISTRO DE ESTRATEGIAS
# ─────────────────────────────────────────────
ESTRATEGIAS = {
    'sop_res': estrategia_soporte_resistencia,
    'pin_bar': estrategia_pin_bar,
    'rechazo': estrategia_vela_rechazo,
}

ESTRATEGIA_NOMBRES = {
    'sop_res': 'Soporte/Resistencia',
    'pin_bar': 'Pin Bar',
    'rechazo': 'Vela de Rechazo',
}

# Todas las estrategias operan a 5 minutos
ESTRATEGIA_DURACION = {
    'sop_res': 5,
    'pin_bar': 5,
    'rechazo': 5,
}


# ─────────────────────────────────────────────
# ANÁLISIS POR ACTIVO
# ─────────────────────────────────────────────
def analizar_activo(api, asset, state):
    """
    Pipeline de analisis con las 3 estrategias y filtros obligatorios.
    Retorna dict de señal o None.
    """
    try:
        # Solo operar activos del listado objetivo
        if asset not in ACTIVOS_OBJETIVO:
            return None

        if not state.puede_operar_asset(asset):
            return None

        df = obtener_velas(api, asset, n=100)
        if df is None or len(df) < 30:
            return None

        df = calcular_indicadores(df)

        # ── Regla de Tendencia Obligatoria ────────────────────────────────
        regimen = detectar_regimen(df)
        state.regimenes[asset] = regimen

        # MERCADO LATERAL: no operar
        if regimen == 'SIDEWAYS':
            return None

        # ── Evaluar las 3 estrategias ─────────────────────────────────────
        ahora_dt   = datetime.now(ecuador)
        votos_call = []
        votos_put  = []

        for nombre, fn in ESTRATEGIAS.items():
            if not state.estrategias_activas.get(nombre, True):
                continue
            bloqueo = state.bloqueo_asset_est.get((asset, nombre), {})
            bloqueado_hasta = bloqueo.get('bloqueado_hasta')
            if bloqueado_hasta and ahora_dt < bloqueado_hasta:
                continue
            try:
                direction, score = fn(df, regimen)
                if direction and score > 0:
                    if direction == 'CALL':
                        votos_call.append((nombre, score))
                    else:
                        votos_put.append((nombre, score))
            except Exception:
                pass

        # ── Log de acercamiento ────────────────────────────────────────────
        total_votos = len(votos_call) + len(votos_put)
        if total_votos >= 1:
            u_log = df.iloc[-1]
            mfm_v  = round(float(u_log.get('mfm', 0)), 3)
            cmf_v  = round(float(u_log.get('cmf10', 0)), 3)
            sk_v   = round(float(u_log.get('stoch_k', 50)), 1)
            estado = "🟡 1 voto" if total_votos == 1 else f"🟠 {total_votos} votos"
            dir_v  = "CALL" if len(votos_call) >= len(votos_put) else "PUT"
            state.add_log(
                f"{estado} {asset} {dir_v} [{regimen}] MFM={mfm_v} CMF={cmf_v} Stoch={sk_v}",
                "INFO"
            )

        # ── Minimo 2 estrategias en acuerdo ───────────────────────────────
        score_call = sum(s for _, s in votos_call)
        score_put  = sum(s for _, s in votos_put)

        if len(votos_call) < 2 and len(votos_put) < 2:
            return None

        if score_call >= score_put:
            dir_ganadora  = 'CALL'
            votos_ganador = votos_call
        else:
            dir_ganadora  = 'PUT'
            votos_ganador = votos_put

        n_acuerdo = len(votos_ganador)
        if n_acuerdo < 2:
            return None

        # ── Regla de Tendencia: direccion debe coincidir con regimen ──────
        if regimen == 'BULL' and dir_ganadora != 'CALL':
            return None
        if regimen == 'BEAR' and dir_ganadora != 'PUT':
            return None

        # ── Filtro Global (Normal vs OTC) ─────────────────────────────────
        ok_filtro, msg_filtro = filtro_global(df, asset, dir_ganadora)
        if not ok_filtro:
            state.add_log(f"⚠️ {asset} bloqueado filtro: {msg_filtro}", "WARN")
            return None

        # ── Score final ───────────────────────────────────────────────────
        mejor_score = max(s for _, s in votos_ganador)
        mejor_est   = max(votos_ganador, key=lambda x: x[1])[0]

        bonus = 12 if n_acuerdo >= 3 else 6
        score_final = min(mejor_score + bonus, 100)

        if n_acuerdo >= 3:
            nombres_acuerdo = "+".join(ESTRATEGIA_NOMBRES.get(n, n) for n, _ in votos_ganador)
        else:
            nombres_acuerdo = "+".join(ESTRATEGIA_NOMBRES.get(n, n) for n, _ in votos_ganador[:2])

        if score_final >= UMBRAL_PRESENAL:
            with _scan_lock:
                state._lista_caliente[asset] = score_final

        if score_final < MIN_SCORE_PARA_OPERAR:
            return None

        confianza = state.ia.factor_confianza(asset, mejor_est)
        if confianza < UMBRAL_CONFIANZA_ACTIVO:
            return None

        u = df.iloc[-1]
        return {
            'asset':             asset,
            'direccion':         dir_ganadora,
            'estrategia':        mejor_est,
            'score':             score_final,
            'fuerza':            n_acuerdo * 30,
            'sostenibilidad':    score_final,
            'nombre_estrategia': nombres_acuerdo,
            'regimen':           regimen,
            'confianza_ia':      round(confianza * 100, 1),
            'filtro_calidad':    msg_filtro,
            'mfm':               round(float(u.get('mfm', 0)), 3),
            'cmf10':             round(float(u.get('cmf10', 0)), 3),
            'stoch_k':           round(float(u.get('stoch_k', 50)), 1),
            'duracion':          DURACION_OPERACION,
            'n_estrategias':     n_acuerdo,
            'es_volatil':        False,
        }
    except Exception:
        return None


# ─────────────────────────────────────────────
# EJECUCION DE TRADE
# ─────────────────────────────────────────────
_scan_lock        = _threading.Lock()
_activos_exception = set()


def ejecutar_trade(api, asset, direccion, monto, estrategia, state, duracion=5, es_martingala=False):
    if asset in _activos_exception:
        state.add_log(f"⛔ {asset} bloqueado (fallo anteriormente) — omitiendo", "WARN")
        return False

    if not hasattr(state, 'ops_dia'):
        state.ops_dia = 0
    if not hasattr(state, 'bloqueo_asset_est'):
        state.bloqueo_asset_est = {}

    if len(state.active_trades) >= MAX_CONCURRENT_TRADES:
        return False

    if any(t['asset'] == asset for t in state.active_trades):
        return False

    opcion = "call" if direccion == "CALL" else "put"

    monto_real = monto
    if state.martingala_activa and state.martingala_nivel == 1:
        monto_real = round(state.martingala_monto_base * 2.5, 2)
        state.add_log(
            f"⚡ MARTINGALA Nv1: operando ${monto_real:.2f} "
            f"(base ${state.martingala_monto_base:.2f} × 2.5)",
            "WARN"
        )

    try:
        tipo_op = getattr(state, 'tipo_operacion', 'binaria')
        if tipo_op == 'digital':
            success, order_id = api.buy_digital_spot(asset, monto_real, opcion, duracion)
        else:
            success, order_id = api.buy(monto_real, asset, opcion, duracion)

        if success:
            entrada     = datetime.now(ecuador)
            entrada_str = entrada.strftime("%H:%M:%S")
            venc_str    = (entrada + timedelta(minutes=duracion)).strftime("%H:%M:%S")
            trade = {
                'asset':             asset,
                'direccion':         direccion,
                'monto':             monto_real,
                'entrada':           entrada_str,
                'vencimiento':       venc_str,
                'order_id':          order_id,
                'estado':            'PENDIENTE',
                'estrategia':        estrategia,
                'nombre_estrategia': ESTRATEGIA_NOMBRES.get(estrategia, estrategia),
                'ganancia':          0.0,
                'fecha':             entrada.strftime("%d/%m %H:%M"),
                'regimen':           state.regimenes.get(asset, '?'),
                '_ts_creado':        time.time(),
                '_es_martingala':    state.martingala_activa,
                '_duracion':         duracion,
            }
            state.active_trades.append(trade)
            state.registrar_op(asset)
            state.ops_dia += 1
            tag = " [MARTINGALA]" if state.martingala_activa else ""
            state.add_log(
                f"OPERACION{tag} [5MIN]: {asset} {direccion} ${monto_real:.2f} | "
                f"{ESTRATEGIA_NOMBRES.get(estrategia, estrategia)} | ID:{order_id}",
                "TRADE"
            )
            return True
        else:
            msg = str(order_id) if order_id else "error"
            if "time" in msg.lower() or "purchasing" in msg.lower():
                state.add_log(f"{asset}: tiempo vencido, operacion descartada", "WARN")
            else:
                state.add_log(f"Error al operar {asset}: {msg}", "ERROR")
            return False
    except Exception as e:
        state.add_log(f"Excepcion en trade ({asset}): {e} — bloqueando activo", "ERROR")
        _activos_exception.add(asset)
        return False


# ─────────────────────────────────────────────
# VERIFICACIÓN DE RESULTADO
# ─────────────────────────────────────────────
def verificar_resultado_trade(api, state, trade=None):
    if trade is None:
        trade = state.current_trade
    if trade is None or trade not in state.active_trades:
        return False
    try:
        ahora = datetime.now(ecuador)
        ts_creado = trade.get('_ts_creado', time.time() - 400)
        segundos_desde_apertura = time.time() - ts_creado
        duracion_trade = trade.get('_duracion', 5)
        timeout_seg    = duracion_trade * 60 + 30
        if segundos_desde_apertura > timeout_seg:
            state.add_log(
                f"Trade {trade['asset']} timeout (>{timeout_seg}s) → DEVUELTA", "WARN"
            )
            trade['estado']   = 'DEVUELTA'
            trade['ganancia'] = 0.0
            state.add_trade(trade)
            if trade in state.active_trades:
                state.active_trades.remove(trade)
            return True

        venc_time = datetime.strptime(trade['vencimiento'], "%H:%M:%S").time()
        venc_dt   = datetime.combine(ahora.date(), venc_time)
        if venc_dt.replace(tzinfo=None) < ahora.replace(tzinfo=None):
            venc_dt += timedelta(days=1)
        if ahora.replace(tzinfo=None) < venc_dt.replace(tzinfo=None) - timedelta(seconds=2):
            return False

        resultado = api.check_win_v4(trade['order_id'])
        if resultado is not None:
            if isinstance(resultado, (list, tuple)) and len(resultado) >= 2:
                estado, ganancia = resultado[0], float(resultado[1])
            elif isinstance(resultado, str):
                estado, ganancia = resultado, 0.0
            else:
                estado, ganancia = str(resultado), 0.0

            if estado in ('win', 'Win', 'WIN'):
                trade['estado']   = 'GANADA'
                trade['ganancia'] = ganancia
                state.saldo      += ganancia
                state.add_log(
                    f"GANADA: {trade['asset']} {trade['direccion']} +${ganancia:.2f} [5MIN]",
                    "WIN"
                )
                state.martingala_activa     = False
                state.martingala_nivel      = 0
                state.martingala_monto_base = 0.0
                state.perdidas_consecutivas = 0
                clave = (trade['asset'], trade.get('estrategia', ''))
                if clave in state.bloqueo_asset_est:
                    state.bloqueo_asset_est[clave]['racha'] = 0
                    state.bloqueo_asset_est[clave]['bloqueado_hasta'] = None

            elif estado in ('loose', 'loss', 'Loose', 'LOSE', 'Loss'):
                trade['estado']   = 'PERDIDA'
                trade['ganancia'] = -trade['monto']
                state.saldo      -= trade['monto']
                clave = (trade['asset'], trade.get('estrategia', ''))
                entrada_bloqueo = state.bloqueo_asset_est.get(clave, {'racha': 0, 'bloqueado_hasta': None})
                entrada_bloqueo['racha'] = entrada_bloqueo.get('racha', 0) + 1
                if entrada_bloqueo['racha'] >= 2:
                    entrada_bloqueo['bloqueado_hasta'] = datetime.now(ecuador) + timedelta(hours=1)
                    state.add_log(
                        f"⛔ {trade['asset']} [{ESTRATEGIA_NOMBRES.get(trade.get('estrategia',''), '')}] "
                        f"bloqueado 1h (2 perdidas consecutivas)",
                        "WARN"
                    )
                state.bloqueo_asset_est[clave] = entrada_bloqueo

                if (not state.martingala_activa and
                        state.martingala_nivel < MARTINGALA_MAX_NIVEL):
                    state.martingala_activa     = True
                    state.martingala_nivel      = 1
                    state.martingala_monto_base = trade['monto']
                    siguiente_min = datetime.now(ecuador).replace(second=0, microsecond=0) + timedelta(minutes=1)
                    state.martingala_pendiente = {
                        'asset':       trade['asset'],
                        'direccion':   trade['direccion'],
                        'estrategia':  trade.get('estrategia', ''),
                        'duracion':    DURACION_OPERACION,
                        'monto_base':  trade['monto'],
                        'no_antes_de': siguiente_min,
                    }
                    state.add_log(
                        f"⚡ MARTINGALA programada: {trade['asset']} {trade['direccion']} "
                        f"a las {siguiente_min.strftime('%H:%M')}",
                        "WARN"
                    )
                elif state.martingala_activa:
                    state.martingala_activa     = False
                    state.martingala_nivel      = 0
                    state.martingala_monto_base = 0.0
                    state.add_log(
                        f"⚡ MARTINGALA PERDIDA: {trade['asset']} — volviendo a monto base",
                        "LOSS"
                    )

                state.add_log(
                    f"PERDIDA: {trade['asset']} {trade['direccion']} -${trade['monto']:.2f} [5MIN]",
                    "LOSS"
                )
            else:
                trade['estado']   = 'DEVUELTA'
                trade['ganancia'] = 0.0
                state.add_log(f"DEVUELTA: {trade['asset']} — {estado}", "INFO")

            state.add_trade(trade)
            if trade in state.active_trades:
                state.active_trades.remove(trade)
            return True
        return False
    except Exception as e:
        state.add_log(f"Error verificando resultado: {e}", "WARN")
        return False


def _hilo_verificar_resultado(api, state, trade=None):
    if trade is None:
        trade = state.current_trade
    if not trade:
        return
    duracion_min = trade.get('_duracion', 5)
    max_espera   = duracion_min * 65 + 30
    inicio       = time.time()
    consultado   = False
    while state.running and trade in state.active_trades and (time.time() - inicio) < max_espera:
        try:
            resultado = verificar_resultado_trade(api, state, trade)
            if resultado:
                consultado = True
                break
        except Exception as e:
            state.add_log(f"Verificador resultado: {e}", "WARN")
        time.sleep(1.5)

    if trade in state.active_trades and not consultado:
        trade['estado']   = 'DEVUELTA'
        trade['ganancia'] = 0.0
        state.add_trade(trade)
        if trade in state.active_trades:
            state.active_trades.remove(trade)
        state.add_log(f"Trade {trade['asset']} liberado por timeout del verificador", "WARN")


# ─────────────────────────────────────────────
# RECONEXIÓN
# ─────────────────────────────────────────────
def intentar_reconexion(state):
    try:
        if not state._email or not state._password:
            return False
        from iqoptionapi.stable_api import IQ_Option
        api_nueva = IQ_Option(state._email, state._password)
        check, reason = api_nueva.connect()
        if check:
            state.api = api_nueva
            state.add_log("Reconexion exitosa", "INFO")
            return True
        state.add_log(f"Reconexion fallida: {reason}", "WARN")
        return False
    except Exception as e:
        state.add_log(f"Error en reconexion: {e}", "ERROR")
        return False


# ─────────────────────────────────────────────
# SCANNER DE ACTIVOS
# ─────────────────────────────────────────────
def _analizar_wrapper(args):
    api, asset, state, progreso_ref = args
    try:
        resultado = analizar_activo(api, asset, state)
        with _scan_lock:
            progreso_ref[0] += 1
            state.scan_progreso = progreso_ref[0]
        return resultado
    except Exception:
        with _scan_lock:
            progreso_ref[0] += 1
            state.scan_progreso = progreso_ref[0]
        return None


def _refresh_activos_si_necesario(api, state):
    ahora_ts = time.time()
    if not state.activos_disponibles or (ahora_ts - state._ultimo_refresh_activos) > 1800:
        activos_nuevos = obtener_activos_disponibles(api)
        if activos_nuevos:
            state.activos_disponibles = activos_nuevos
            state._ultimo_refresh_activos = ahora_ts
            state.add_log(f"Activos objetivo disponibles: {len(activos_nuevos)} — {', '.join(activos_nuevos)}", "INFO")


def scan_siguiente_lote(api, state):
    _refresh_activos_si_necesario(api, state)
    activos = state.activos_disponibles
    if not activos:
        activos = ACTIVOS_OBJETIVO

    candidatos = [
        a for a in activos
        if state.puede_operar_asset(a) and a not in _activos_exception
    ]
    if not candidatos:
        return

    total            = len(candidatos)
    state.scan_total = total

    inicio = state._cursor_activos % total
    lote   = candidatos[inicio:]  # todos en cada ciclo (solo 20 activos)
    state._cursor_activos = 0

    progreso_ref = [0]
    args_list    = [(api, a, state, progreso_ref) for a in lote]
    MAX_WORKERS  = min(MAX_SCAN_WORKERS, len(lote))

    nuevos = []
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = [executor.submit(_analizar_wrapper, args) for args in args_list]
        for future in as_completed(futures):
            resultado = future.result()
            if resultado:
                nuevos.append(resultado)

    with _scan_lock:
        state._candidatos_cache.extend(nuevos)
        state._candidatos_cache.sort(key=lambda x: x['score'], reverse=True)
        state._candidatos_cache = state._candidatos_cache[:20]

    if nuevos:
        mejor = max(nuevos, key=lambda x: x['score'])
        state.add_log(
            f"Scan {total} activos → {len(nuevos)} señal(es) "
            f"| Mejor: {mejor['asset']} {mejor['direccion']} "
            f"score={mejor['score']} | Estrat: {mejor['nombre_estrategia']}",
            "INFO"
        )
    else:
        state.add_log(
            f"Scan {total} activos → sin señales validas "
            f"(2+ estrategias + filtros globales + tendencia)",
            "INFO"
        )


def _rechequear_calientes(api, state):
    with _scan_lock:
        calientes = [a for a in state._lista_caliente.keys() if a not in _activos_exception]
    if not calientes:
        return
    state.add_log(
        f"Pre-señal — re-chequeando {len(calientes)} activo(s): "
        f"{', '.join(calientes[:5])}",
        "INFO"
    )
    hot_args    = [(api, a, state, [0]) for a in calientes]
    hot_workers = min(MAX_SCAN_WORKERS, len(calientes))
    nuevos      = []
    with ThreadPoolExecutor(max_workers=hot_workers) as executor:
        futures = [executor.submit(_analizar_wrapper, args) for args in hot_args]
        for future in as_completed(futures):
            r = future.result()
            if r:
                nuevos.append(r)
    if nuevos:
        with _scan_lock:
            state._candidatos_cache.extend(nuevos)
            state._candidatos_cache.sort(key=lambda x: x['score'], reverse=True)
            state._candidatos_cache = state._candidatos_cache[:20]
        mejor = max(nuevos, key=lambda x: x['score'])
        state.add_log(
            f"Pre-señal CONFIRMADA → {mejor['asset']} {mejor['direccion']} "
            f"score={mejor['score']} | {mejor['nombre_estrategia']}",
            "SIGNAL"
        )


def _hilo_scanner(api, state):
    while state.running:
        try:
            if not api or not state.running:
                time.sleep(1)
                continue
            if not state.activos_disponibles:
                _refresh_activos_si_necesario(api, state)
                time.sleep(2)
                continue
            scan_siguiente_lote(api, state)
            elapsed = 0
            while elapsed < PAUSA_ENTRE_LOTES and state.running:
                time.sleep(PAUSA_CALIENTES)
                elapsed += PAUSA_CALIENTES
                _rechequear_calientes(api, state)
        except Exception as e:
            state.add_log(f"Error en scanner: {e}", "ERROR")
            time.sleep(3)


def _verificar_senal_fresca(api, señal, state):
    """Verifica que la señal siga valida con datos frescos."""
    try:
        df = obtener_velas(api, señal['asset'], n=100, forzar_fresco=True)
        if df is None or len(df) < 30:
            return False
        df      = calcular_indicadores(df)
        regimen = detectar_regimen(df)
        if regimen == 'SIDEWAYS':
            return False
        # Verificar que la direccion sigue alineada con tendencia
        dir_senal = señal['direccion']
        if regimen == 'BULL' and dir_senal != 'CALL':
            return False
        if regimen == 'BEAR' and dir_senal != 'PUT':
            return False
        # Verificar filtro global sigue pasando
        ok, _ = filtro_global(df, señal['asset'], dir_senal)
        return ok
    except Exception:
        return True


# ─────────────────────────────────────────────
# MOTOR PRINCIPAL
# ─────────────────────────────────────────────
def bot_engine(state):
    """
    NeuroTrader Pro v7
    3 Estrategias | Vencimiento 5 min | EMA9/EMA21 | Stoch(14,3,3) | CMF(10)
    """
    state.add_log(
        "NeuroTrader Pro v7 — 3 Estrategias [S/R + PinBar + Rechazo] | 5 MIN | EMA9/EMA21",
        "INFO"
    )
    state.add_log(
        f"Activos vigilados: {len(ACTIVOS_OBJETIVO)} — {', '.join(ACTIVOS_OBJETIVO[:5])}...",
        "INFO"
    )

    ultimo_minuto_operado = -1
    intentos_reconexion   = 0
    MAX_INTENTOS_RECONEX  = 5
    _ultimo_log_min       = -1

    hilo_scan = _threading.Thread(
        target=_hilo_scanner,
        args=(state.api, state),
        daemon=True,
        name="neuro-scanner-v7"
    )
    hilo_scan.start()
    state.add_log("Hilo scanner iniciado — analizando activos objetivo...", "INFO")

    def _disparar_señal(señal):
        if any(t['asset'] == señal['asset'] for t in state.active_trades):
            return False
        if len(state.active_trades) >= MAX_CONCURRENT_TRADES:
            return False
        dur = señal.get('duracion', DURACION_OPERACION)
        n_est = señal.get('n_estrategias', 2)
        consenso_tag = f" ⚡×{n_est}" if n_est >= 2 else ""
        ahora_ent = datetime.now(ecuador)
        tipo_tag  = " [DIGITAL]" if getattr(state, 'tipo_operacion', 'binaria') == 'digital' else ""
        state.add_log(
            f"▶ ENTRADA{tipo_tag} [5MIN]{consenso_tag} s{ahora_ent.second} — "
            f"{señal['asset']} {señal['direccion']} "
            f"| Score:{señal['score']} "
            f"| IA:{señal['confianza_ia']}% "
            f"| {señal['nombre_estrategia']} "
            f"| {señal['regimen']}",
            "SIGNAL"
        )
        ok = ejecutar_trade(
            state.api, señal['asset'], señal['direccion'],
            state.monto, señal['estrategia'], state, duracion=dur
        )
        if ok:
            nuevo_trade = state.active_trades[-1] if state.active_trades else None
            hilo_v = _threading.Thread(
                target=_hilo_verificar_resultado,
                args=(state.api, state, nuevo_trade),
                daemon=True, name=f"verificador-{señal['asset']}"
            )
            hilo_v.start()
        return ok

    while state.running:
        try:
            if not state.api:
                time.sleep(0.5)
                continue

            try:
                conectado = state.api.check_connect()
            except Exception:
                conectado = False

            if not conectado:
                intentos_reconexion += 1
                state.add_log(
                    f"Conexion perdida. Intento {intentos_reconexion}/{MAX_INTENTOS_RECONEX}...",
                    "WARN"
                )
                if intentos_reconexion <= MAX_INTENTOS_RECONEX:
                    time.sleep(3)
                    if intentar_reconexion(state):
                        intentos_reconexion = 0
                    continue
                else:
                    state.add_log("No se pudo reconectar. Deteniendo bot.", "ERROR")
                    state.running = False
                    break

            intentos_reconexion = 0

            ahora         = datetime.now(ecuador)
            segundo       = ahora.second
            minuto_actual = ahora.minute

            # Limpiar cache en segundo 2, despues de la ventana s59-s01
            if 2 <= segundo <= 4 and minuto_actual != state._ultimo_ciclo_min:
                with _scan_lock:
                    state._candidatos_cache = []
                    state._cursor_activos   = 0
                    state._lista_caliente   = {}
                state._ultimo_ciclo_min = minuto_actual
                ts_ahora = time.time()
                claves_exp = [
                    a for a, (ts, _) in list(_velas_cache.items())
                    if ts_ahora - ts > 120
                ]
                for a in claves_exp:
                    _velas_cache.pop(a, None)
                state.add_log(
                    f"⏱ Min {minuto_actual:02d} — cache limpiado | "
                    f"{len(state.activos_disponibles or ACTIVOS_OBJETIVO)} activos en analisis",
                    "INFO"
                )

            en_ventana_entrada = segundo >= 59 or segundo <= 1

            # Martingala pendiente
            if (len(state.active_trades) < MAX_CONCURRENT_TRADES and
                    getattr(state, 'martingala_pendiente', None) and
                    en_ventana_entrada):
                pend    = state.martingala_pendiente
                ahora_n = datetime.now(ecuador)
                no_antes = pend.get('no_antes_de', ahora_n)
                if ahora_n < no_antes:
                    time.sleep(0.1)
                    continue
                state.add_log(
                    f"⚡ MARTINGALA: ejecutando {pend['asset']} {pend['direccion']}...",
                    "WARN"
                )
                state.martingala_pendiente = None
                _monto_nv = round(state.martingala_monto_base * 2.5, 2)
                state.add_log(
                    f"⚡ MARTINGALA Nv{state.martingala_nivel} → {pend['asset']} "
                    f"{pend['direccion']} ${_monto_nv:.2f} (×2.5)",
                    "WARN"
                )
                ok_pend = ejecutar_trade(
                    state.api,
                    pend['asset'], pend['direccion'],
                    state.monto,
                    pend.get('estrategia', ''),
                    state,
                    duracion=pend.get('duracion', DURACION_OPERACION),
                    es_martingala=True
                )
                if ok_pend:
                    trade_mp = state.active_trades[-1] if state.active_trades else None
                    hilo_mp = _threading.Thread(
                        target=_hilo_verificar_resultado,
                        args=(state.api, state, trade_mp),
                        daemon=True, name=f"verificador-mart-{pend['asset']}"
                    )
                    hilo_mp.start()
                time.sleep(0.1)
                continue

            # Pausa protectora
            if state.pausa_hasta:
                if datetime.now(ecuador) < state.pausa_hasta:
                    diff = int((state.pausa_hasta - datetime.now(ecuador)).total_seconds())
                    if diff % 30 == 0:
                        state.add_log(
                            f"Pausa protectora — reanuda en {diff//60}m {diff%60}s", "WARN"
                        )
                    time.sleep(5)
                    continue
                else:
                    state.pausa_hasta = None
                    state.perdidas_consecutivas = 0
                    state.add_log("Pausa terminada. Operaciones reanudadas.", "INFO")

            if not state.activos_disponibles:
                time.sleep(0.5)
                continue

            # Ejecucion en ventana s59-s01
            if (minuto_actual != ultimo_minuto_operado and
                    en_ventana_entrada and
                    len(state.active_trades) < MAX_CONCURRENT_TRADES):
                ultimo_minuto_operado = minuto_actual

                with _scan_lock:
                    cache_snap = list(state._candidatos_cache)

                if cache_snap:
                    top = sorted(cache_snap, key=lambda x: x['score'], reverse=True)
                    disparadas = 0
                    for candidato in top[:3]:
                        if candidato['score'] < MIN_SCORE_PARA_OPERAR:
                            break
                        if disparadas >= MAX_CONCURRENT_TRADES - len(state.active_trades):
                            break
                        if _verificar_senal_fresca(state.api, candidato, state):
                            state.señal_actual = candidato
                            if _disparar_señal(candidato):
                                disparadas += 1
                        else:
                            with _scan_lock:
                                if candidato in state._candidatos_cache:
                                    state._candidatos_cache.remove(candidato)

                    if disparadas == 0 and minuto_actual != _ultimo_log_min:
                        state.señal_actual = None
                        top_s = top[0]['score'] if top else 0
                        top_a = top[0]['asset'] if top else '-'
                        state.add_log(
                            f"Min {minuto_actual:02d} — score max={top_s} ({top_a}) "
                            f"— sin señal valida (verificacion fresca)",
                            "WARN"
                        )
                else:
                    if minuto_actual != _ultimo_log_min:
                        state.señal_actual = None
                        state.add_log(
                            f"Min {minuto_actual:02d} — cache vacio, esperando escaneo...",
                            "INFO"
                        )

                _ultimo_log_min = minuto_actual

            time.sleep(0.1)

        except Exception as e:
            state.add_log(f"Error en motor: {e}", "ERROR")
            time.sleep(1)
