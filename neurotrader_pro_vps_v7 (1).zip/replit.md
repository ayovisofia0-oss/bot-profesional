# NEUROTRADER PRO

## Overview
This project is a Python Streamlit application for a NEUROTRADER PRO IQ Option trading bot. The main app is served from `main.py`, with trading logic in `bot_engine.py` and license data stored in `licencias.json`.

## Project Structure
- `main.py` - primary Streamlit UI for IQ Option credentials, bot controls, metrics, logs, and trading dashboard.
- `bot_engine.py` - bot state, license validation, analysis/scoring logic, and IQ Option trading engine helpers.
- `pages/1_🔑_Gestor_Licencias.py` - Streamlit multipage admin panel for creating, editing, renewing, deleting, and managing licenses.
- `license_manager.py` - standalone Streamlit license manager entry point.
- `licencias.json` - JSON-backed license store used by the app and admin panel.
- `.streamlit/config.toml` - Streamlit runtime configuration for Replit preview on port 5000.
- `requirements.txt` - Python dependencies, including Streamlit, data/science packages, TA indicators, and IQ Option API from GitHub.

## Runtime Configuration
The Replit workflow `Start application` runs:

```bash
python -m streamlit run main.py --server.address=0.0.0.0 --server.port=5000 --server.headless=true --server.enableCORS=false --server.enableXsrfProtection=false
```

The app must listen on `0.0.0.0:5000` for the Replit web preview. Streamlit CORS/XSRF checks are disabled for development preview compatibility through Replit's iframe proxy.

## Deployment
Deployment is configured as an autoscale web app using the same Streamlit run command on port 5000.

## Trading Rules (v7)
- **3 Strategies only**: Soporte/Resistencia (`sop_res`), Pin Bar (`pin_bar`), Vela de Rechazo (`rechazo`).
- **Expiration**: All operations at 5 minutes.
- **Trend Rule (mandatory)**: CALL only when EMA9 > EMA21 (BULL); PUT only when EMA9 < EMA21 (BEAR); no trades in SIDEWAYS market.
- **Minimum consensus**: at least 2 strategies must agree before a trade is placed.
- **Global Filter - Normal market**: MFM >= 0.52 directional, CMF(10) > 0 for CALL / < 0 for PUT, Stoch%K < 83 for CALL / > 17 for PUT.
- **Global Filter - OTC market**: MFM >= 0.58 directional, CMF(10) > 0 for CALL / < 0 for PUT, Stoch%K < 83 for CALL / > 17 for PUT.
- **Stochastic**: Stochastic(14,3,3) — %K and %D both smoothed (replaces RSI).
- **Monitored assets (Normal)**: EURUSD, GBPUSD, USDJPY, AUDUSD, XAUUSD, GBPJPY, EURJPY, USDCAD, NZDUSD, USDCHF (plain names, no suffix — required by IQ Option API).
- **Monitored assets (OTC)**: EURUSD-OTC, GBPUSD-OTC, USDJPY-OTC, EURGBP-OTC, EURJPY-OTC, GBPJPY-OTC, NZDUSD-OTC, USDCHF-OTC, AUDCAD-OTC, USDSGD-OTC (all verified present in iqoptionapi constants).
- Trade execution uses the s59-s01 entry window.
- Martingale limited to level 1 only.

## License Manager
- The admin password defaults to `neurotrader2007` if `ADMIN_PASSWORD` is not set.
- The main license manager page supports creating, renewing, listing/exporting, and deleting licenses.
- For production, set `ADMIN_PASSWORD` as an environment secret.

## Notes
- The trading bot requires user-provided IQ Option credentials and a valid license code at runtime.
